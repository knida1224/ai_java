/**
 * This package provides an generic apporach to the Monte-Carlo-Localization algorithm.<br/>
 * The sub-packages of {@code impl} provide functionality for a two-dimensional environment.
 */
package aima.core.robotics;